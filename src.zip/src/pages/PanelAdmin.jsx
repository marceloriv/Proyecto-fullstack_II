// src/Pages/PanelAdmin.jsx
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Container, Row, Col, Card, Table, Button, Alert, Form, Spinner } from 'react-bootstrap'
import { useAuth } from '/src/Contexts/AuthContext.jsx'

export default function PanelAdmin() {
  const { user, getUsers, logout } = useAuth()
  const navigate = useNavigate()
  const [users, setUsers] = useState([])
  const [filtro, setFiltro] = useState('')
  const [cargando, setCargando] = useState(true)
  const [errorCarga, setErrorCarga] = useState('')

  useEffect(() => {
    // Si no hay usuario o no es admin, lo mandamos al login
    if (!user || !user.isAdmin) {
      navigate('/login', { replace: true })
      return
    }

    let activo = true
    const cargar = async () => {
      setCargando(true)
      setErrorCarga('')
      try {
        const lista = await getUsers()
        if (!activo) return
        setUsers((lista || []).filter(Boolean))
      } catch (err) {
        if (!activo) return
        setErrorCarga(err?.message || 'No se pudo cargar la lista de usuarios.')
        setUsers([])
      } finally {
        if (activo) setCargando(false)
      }
    }

    cargar()
    return () => { activo = false }
  }, [user, getUsers, navigate])

  const handleLogout = () => {
    logout()
    navigate('/login', { replace: true })
  }

  const usuariosFiltrados = users.filter(u => {
    const q = filtro.toLowerCase()
    return (
      u.nombre?.toLowerCase().includes(q) ||
      u.username?.toLowerCase().includes(q) ||
      u.email?.toLowerCase().includes(q)
    )
  })

  if (!user || !user.isAdmin) {
    // Render rápido por si el useEffect aún no redirige
    return (
      <Container className="py-4">
        <Alert variant="danger">No tienes permisos para ver esta página.</Alert>
      </Container>
    )
  }

  return (
    <Container className="py-4">
      <Row className="mb-3 align-items-center">
        <Col>
          <h1 className="mb-0">Panel de Administrador</h1>
          <small className="text-muted">
            Sesión iniciada como <strong>{user.nombre || user.username}</strong> ({user.email})
          </small>
        </Col>
        <Col className="text-end">
          <Button variant="outline-danger" size="sm" onClick={handleLogout}>
            Cerrar sesión
          </Button>
        </Col>
      </Row>

      <Row className="mb-4">
        <Col md={4}>
          <Card>
            <Card.Body>
              <Card.Title>Resumen rápido</Card.Title>
              <p className="mb-1">Total de usuarios registrados:</p>
              <h3>{users.length}</h3>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row>
        <Col>
          <Card>
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <Card.Title className="mb-0">Usuarios</Card.Title>
                <Form.Control
                  size="sm"
                  style={{ maxWidth: '250px' }}
                  placeholder="Buscar por nombre, usuario o correo…"
                  value={filtro}
                  onChange={e => setFiltro(e.target.value)}
                />
              </div>

              {errorCarga && (
                <Alert variant="danger" className="mb-3">
                  {errorCarga}
                </Alert>
              )}

              {cargando ? (
                <div className="text-center py-4">
                  <Spinner animation="border" />
                </div>
              ) : usuariosFiltrados.length === 0 ? (
                <Alert variant="info">No hay usuarios que coincidan con la búsqueda.</Alert>
              ) : (
                <Table striped hover responsive>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Nombre</th>
                      <th>Usuario</th>
                      <th>Correo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {usuariosFiltrados.map((u, i) => (
                      <tr key={u.id || i}>
                        <td>{i + 1}</td>
                        <td>{u.nombre}</td>
                        <td>{u.username}</td>
                        <td>{u.email}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}
