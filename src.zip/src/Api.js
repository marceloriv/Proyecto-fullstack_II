import axios from "axios";

const DEFAULT_BASE_URL = "http://34.228.80.22:8080/api";

const envBaseUrl = typeof import.meta.env.VITE_API_URL === "string"
  ? import.meta.env.VITE_API_URL.trim()
  : "";

const api = axios.create({
  baseURL: envBaseUrl || DEFAULT_BASE_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 10000,
});

export default api;