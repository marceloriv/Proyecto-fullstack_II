import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import api from '../Api'

const AuthContext = createContext(null)
export const useAuth = () => useContext(AuthContext)

const SESSION_KEY = 'tg_session'
const ALIAS_KEY = 'tg_user_aliases'
const ADMIN_EMAIL = 'ad.admin@admin.com'
const ADMIN_EMAIL_LOWER = ADMIN_EMAIL.toLowerCase()

const stripLinks = (entity) => {
  if (!entity || typeof entity !== 'object') return entity
  const { _links, ...rest } = entity
  return rest
}

const extractCollection = (payload) => {
  if (!payload) return []
  if (Array.isArray(payload)) return payload.map(stripLinks)
  const embedded = payload._embedded
  if (embedded) {
    if (Array.isArray(embedded.usuarios)) return embedded.usuarios.map(stripLinks)
    if (Array.isArray(embedded.Usuarios)) return embedded.Usuarios.map(stripLinks)
    if (Array.isArray(embedded.usuarioModelList)) return embedded.usuarioModelList.map(stripLinks)
    if (Array.isArray(embedded.UsuarioModelList)) return embedded.UsuarioModelList.map(stripLinks)
  }
  return []
}

const loadStoredAliases = () => {
  try {
    const raw = localStorage.getItem(ALIAS_KEY)
    return raw ? JSON.parse(raw) : {}
  } catch {
    return {}
  }
}

const loadStoredSession = () => {
  try {
    const raw = localStorage.getItem(SESSION_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [welcomeMessage, setWelcomeMessage] = useState(null)
  const [aliases, setAliases] = useState(loadStoredAliases)
  const welcomeTimerRef = useRef(null)

  const aliasForEmail = useCallback((email) => {
    const key = String(email || '').trim().toLowerCase()
    return key ? aliases[key] : undefined
  }, [aliases])

  const emailForAlias = useCallback((alias) => {
    const target = String(alias || '').trim().toLowerCase()
    if (!target) return undefined
    const entry = Object.entries(aliases).find(([, value]) => String(value || '').toLowerCase() === target)
    return entry ? entry[0] : undefined
  }, [aliases])

  const upsertAlias = useCallback((email, username) => {
    const normalizedEmail = String(email || '').trim().toLowerCase()
    const normalizedUsername = String(username || '').trim()
    if (!normalizedEmail || !normalizedUsername) return
    setAliases(prev => {
      const current = prev || {}
      if (current[normalizedEmail] === normalizedUsername) return current
      const next = { ...current, [normalizedEmail]: normalizedUsername }
      try { localStorage.setItem(ALIAS_KEY, JSON.stringify(next)) } catch {}
      return next
    })
  }, [])

  const makeSessionUser = useCallback((raw, fallbackUsername) => {
    if (!raw) return null
    const base = stripLinks(raw)
    const email = (base.correo || base.email || '').trim()
    const storedAlias = aliasForEmail(email)
    const cleanedFallback = String(fallbackUsername || '').trim()
    let username = (base.username || base.usuario || storedAlias || cleanedFallback)
    if (!username && email.includes('@')) username = email.split('@')[0]

    return {
      id: base.id,
      nombre: base.nombre || base.name || '',
      username,
      email,
      telefono: base.telefono ?? '',
      direccion: base.direccion ?? '',
      isAdmin: !!(email && email.toLowerCase() === ADMIN_EMAIL_LOWER)
    }
  }, [aliasForEmail])

  const fetchUserByEmail = useCallback(async (email) => {
    const target = String(email || '').trim()
    if (!target) return null
    try {
      const { data } = await api.get(`/usuarios/correo/${encodeURIComponent(target)}`)
      return stripLinks(data)
    } catch (err) {
      if (err?.response?.status === 404) return null
      throw err
    }
  }, [])

  const fetchUsersRaw = useCallback(async () => {
    const { data } = await api.get('/usuarios')
    return extractCollection(data)
  }, [])

  useEffect(() => () => {
    if (welcomeTimerRef.current) {
      clearTimeout(welcomeTimerRef.current)
      welcomeTimerRef.current = null
    }
  }, [])

  useEffect(() => {
    upsertAlias(ADMIN_EMAIL, 'admin')
  }, [upsertAlias])

  useEffect(() => {
    const stored = loadStoredSession()
    if (!stored?.email) return
    let active = true
    ;(async () => {
      try {
        const remote = await fetchUserByEmail(stored.email)
        if (!active) return
        if (!remote) {
          localStorage.removeItem(SESSION_KEY)
          setUser(null)
          return
        }
        const sessionUser = makeSessionUser(remote, stored.username)
        setUser(sessionUser)
      } catch {
        if (active) {
          localStorage.removeItem(SESSION_KEY)
          setUser(null)
        }
      }
    })()
    return () => { active = false }
  }, [fetchUserByEmail, makeSessionUser])

  const showWelcome = useCallback((message) => {
    if (welcomeTimerRef.current) clearTimeout(welcomeTimerRef.current)
    setWelcomeMessage(message)
    welcomeTimerRef.current = setTimeout(() => setWelcomeMessage(null), 4000)
  }, [])

  const persistSession = useCallback((sessionUser) => {
    if (!sessionUser?.email) return
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify({
        email: sessionUser.email,
        username: sessionUser.username,
      }))
    } catch {}
  }, [])

  const register = useCallback(async (payload = {}) => {
    const fromForm = payload && typeof payload.get === 'function'
    const pick = (obj, ...keys) => {
      for (const key of keys) {
        const value = fromForm ? obj.get(key) : obj[key]
        if (value !== undefined && value !== null && String(value).trim() !== '') return String(value).trim()
      }
      return ''
    }

    const nombre = pick(payload, 'nombre', 'name')
    const username = pick(payload, 'username', 'user', 'usuario')
    const email = pick(payload, 'email', 'correo', 'mail')
    const password = pick(payload, 'password', 'pass')
    const confirmPassword = pick(payload, 'confirmPassword', 'passwordConfirm')
    const telefonoRaw = pick(payload, 'telefono', 'phone')
    const direccion = pick(payload, 'direccion', 'address')

    if (!nombre || nombre.length < 3) throw new Error('El nombre debe tener al menos 3 caracteres')
    if (!username || username.length < 3) throw new Error('El nombre de usuario debe tener al menos 3 caracteres')
    if (/\s/.test(username)) throw new Error('El nombre de usuario no puede contener espacios')
    if (!emailRegex.test(email)) throw new Error('Correo inválido')
    if (!password || password.length < 8) throw new Error('La contraseña debe tener al menos 8 caracteres')
    if (confirmPassword && confirmPassword !== password) throw new Error('Las contraseñas no coinciden')

    const requestBody = { nombre, correo: email, password }
    const digits = telefonoRaw.replace(/[^0-9]/g, '')
    if (!digits) throw new Error('El teléfono es obligatorio')
    if (digits.length < 7) throw new Error('El teléfono debe tener al menos 7 dígitos')
    requestBody.telefono = Number(digits)
    if (direccion) requestBody.direccion = direccion

    try {
      await api.post('/usuarios', requestBody)
      const created = await fetchUserByEmail(email)
      if (!created) throw new Error('No se pudo verificar el usuario creado.')
      const rawUser = { ...stripLinks(created), username }
      if (!rawUser.correo && rawUser.email) rawUser.correo = rawUser.email
      const sessionUser = makeSessionUser(rawUser, username)
      upsertAlias(sessionUser.email, sessionUser.username)
      return sessionUser
    } catch (err) {
      const status = err?.response?.status
      if (status === 400 || status === 409) {
        const message = err.response?.data?.message || 'Los datos ingresados no son válidos.'
        throw new Error(message)
      }
      throw new Error('No se pudo registrar el usuario. Inténtalo nuevamente más tarde.')
    }
  }, [makeSessionUser, upsertAlias])

  const login = useCallback(async ({ username, password }) => {
    const identifier = String(username || '').trim()
    const secret = String(password || '').trim()
    if (!identifier || !secret) throw new Error('Usuario y contraseña son requeridos.')

    let emailToLookup = identifier
    if (!identifier.includes('@')) {
      const aliasEmail = emailForAlias(identifier)
      if (!aliasEmail) throw new Error('Inicia sesión usando tu correo electrónico.')
      emailToLookup = aliasEmail
    }

    let rawUser
    try {
      rawUser = await fetchUserByEmail(emailToLookup)
    } catch {
      throw new Error('No se pudo contactar el servicio de usuarios.')
    }

    if (!rawUser || String(rawUser.password || '') !== secret)
      throw new Error('Usuario o contraseña inválidos.')

    const sessionUser = makeSessionUser(rawUser, identifier)
    upsertAlias(sessionUser.email, sessionUser.username || identifier)
    setUser(sessionUser)
    persistSession(sessionUser)
    showWelcome(`Bienvenido${sessionUser.nombre ? `, ${sessionUser.nombre}` : ''}!`)
    return sessionUser
  }, [emailForAlias, fetchUserByEmail, makeSessionUser, persistSession, showWelcome, upsertAlias])

  const logout = useCallback(() => {
    if (welcomeTimerRef.current) {
      clearTimeout(welcomeTimerRef.current)
      welcomeTimerRef.current = null
    }
    setUser(null)
    setWelcomeMessage(null)
    try { localStorage.removeItem(SESSION_KEY) } catch {}
  }, [])

  const getUsers = useCallback(async () => {
    try {
      const list = await fetchUsersRaw()
      return list.map(item => {
        const sessionUser = makeSessionUser(item)
        if (sessionUser?.email && sessionUser?.username) upsertAlias(sessionUser.email, sessionUser.username)
        return sessionUser
      })
    } catch (err) {
      const message = err?.response?.data?.message || 'No se pudo obtener la lista de usuarios.'
      throw new Error(message)
    }
  }, [fetchUsersRaw, makeSessionUser, upsertAlias])

  return (
    <AuthContext.Provider value={{ user, welcomeMessage, register, login, logout, getUsers }}>
      {children}
    </AuthContext.Provider>
  )
}